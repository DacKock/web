<!DOCTYPE html>
<html>
    <head>
        <title>Головна</title>
        <meta charset="utf-8">
    </head>
    <body>
        <p>Вітаю! Ви успішно авторизувались!</p>
        <a href="processing.php">
            <input type="submit" value="Вийти з сайту">
        </a>
    </body>
</html>
